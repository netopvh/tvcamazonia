<?php
/** Don't load directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
define( 'FOXIZ_LICENSE_ID', 'foxiz_license_id' );
define( 'FOXIZ_IMPORT_ID', 'foxiz_import_id' );
define( 'FOXIZ_ADMIN_NAMESPACE', 'foxiz-admin' );
define( 'RB_API_URL', 'https://api.themeruby.com' );